bs_india_indonesia - ready website package

Upload the files in this folder to static web hosting. index.html is the homepage. Before publishing, replace YOUR-DOMAIN.example in robots.txt and sitemap.xml with your real domain. Then add the domain to Google Search Console and submit sitemap.xml.

The pages use Tailwind CDN and external image URLs, so those assets need internet access.
